import yaml
import argparse
from fvcore.common.config import CfgNode

class MyConfig:
    def __init__(self, yaml_path):
        self.cfg = CfgNode()
        self.cfg.TRAIN = CfgNode()    # 每一级都要这样新建一个节点
        self.cfg.TRAIN.RESUME_PATH = ""
        self.cfg.TRAIN.DATASET = ""
        self.cfg.TRAIN.BATCH_SIZE = 32
        self.cfg.TRAIN.TOTAL_BATCH_SIZE = 64

        self.cfg.SOLVER = CfgNode()  # 每一级都要这样新建一个节点
        self.cfg.SOLVER.MOMENTUM = 0.9
        self.cfg.SOLVER.WEIGHT_DECAY = 5e-4

        self.load_from_config(yaml_path)

    def load_from_config(self, yaml_path):
        self.cfg.merge_from_file(yaml_path) # 将配置信息从文件中加载并合并到配置对象中

    def get_config(self):
        return self.cfg

yaml_path = "./config.yaml"
config = MyConfig(yaml_path)
config1 = config.get_config()
print(config1)
print(config1.TRAIN.RESUME_PATH)
