import torch.utils.data as data
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from PIL import Image
import os
import torch
import cv2
import numpy as np

class_cifar10_dict = {'airplane': 0, 'automobile': 1, 'bird': 2,
              'cat': 3, 'deer': 4, 'dog': 5,'frog': 6,
              'horse': 7, 'ship': 8, 'truck': 9}

class_dog2cat_dict = {'dog': 0, 'cat': 1}

# 这种加载方法只适应于多个类别分别的分类问题
class MyDataset(data.Dataset):
    # classdataset主要有三个函数组成
    def __init__(self, data_folder):
        # 构造函数又为初始化函数，传入参数data_folder，
        # 在创建类时自动调用，用于对象的初始化操作初始化函数用于完成两个静态变量的赋值
        self.data_folder = data_folder # data_folder -> per_calss -> data
        self.filenames = [] # 用于存储数据路径变量
        self.labels = [] # 存储标签变量
        per_classes = os.listdir(data_folder)

        for per_class in per_classes:
            per_class_paths = os.path.join(data_folder, per_class)
            label = torch.tensor(class_cifar10_dict[per_class])
            per_datas = os.listdir(per_class_paths)
            for per_data in per_datas:
                self.filenames.append(os.path.join(per_class_paths, per_data))
                self.labels.append(label)

    # 根据索引返回对应的数据
    def __getitem__(self, index):
        image = Image.open(self.filenames[index])
        label = self.labels[index]
        data = self.proprecess(image)
        return data, label

    def __len__(self):
        return len(self.filenames)

    # 常规的预处理手段将任意格式的data通过一些列基本操作之后以batch tensor的格式输出
    def proprecess(self, data):
        transform_train_list = [
            transforms.Resize((28, 28), interpolation=3),
            transforms.Pad(0, padding_mode='edge'),
            # transforms.RandomCrop((64, 64)),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            # transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]) #适用imageNet的经验值
            # transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]) #符合正态分布
        ]
        return transforms.Compose(transform_train_list)(data)

# 数据增强  随机擦除操作
class RandomErasing(object):
    def __init__(self):
        pass
    def __call__(self, *args, **kwargs):
        pass

def RGBA_test():
    pass

#测试单张图片
def showSignalImg(index):
    data_folder = '/home/thui/projects/datasets/dog2cat/dogcat/'
    try:
        if os.path.exists(data_folder):
            print(f"加载的路径存为：{data_folder}")
        else:
            print(f"错误,路径不存在：{data_folder}")
            return 0
        # 实例化
        my_dataset = MyDataset(data_folder)
        # 获取数据集的长度
        dataset_length = my_dataset.__len__()
        print(f"数据集的长度为:{dataset_length}")
        # 获取数据信息
        sample_data, sample_label = my_dataset.__getitem__(index)
        print(f"当前图片的索引为:{sample_label}")

        # 将tensor转换为numpy数组 使用openCV进行可视化
        sample_data_np = (sample_data.numpy()*255).astype(np.uint8)
        sample_data_np = np.squeeze(sample_data_np)
        # 不是len(sample_data_np.shape())   元组不可调用
        if len(sample_data_np.shape) == 2: # 灰度图 H W
            sample_data_np = np.stack([sample_data_np] * 3, axis=-1)
            # sample_data_np[:, :] = np.stack([sample_data_np] * 3, axis=-1)
        elif len(sample_data_np.shape) == 3: # 彩色图中 C H W
            if sample_data_np.shape[0] == 3: # 通道数为3, R G B
                sample_data_np = np.transpose(sample_data_np, (1, 2, 0)) #变换为 H W C
            elif sample_data_np.shape[0] == 4: # 通道数为4, R G B A
                sample_data_np = sample_data_np[:3, :, :]
                sample_data_np = np.transpose(sample_data_np, (1, 2, 0)) #变换为 H W C
            # 获得图片尺寸大小
        height, width, _ = sample_data_np.shape
        # Create a resizable window
        cv2.namedWindow('Sample Image', cv2.WINDOW_NORMAL)
        # Adjust the window size based on image dimensions
        cv2.resizeWindow('Sample Image', width, height)
        cv2.imshow("Sample Image", sample_data_np)
        cv2.waitKey(0)

    except Exception as e:
        print(f"错误发生: {e}")

# 测试整个数据集
# 返回通道数不为3的图片的索引
from tqdm import tqdm
from time import sleep
def testAllImg():
    data_folder = '/home/thui/projects/datasets/dog2cat/dogcat/'
    try:
        if os.path.exists(data_folder):
            print(f"测试所有数据集加载的路径为：{data_folder}")
        else:
            print(f"测试所有数据集加载的路径不存在：{data_folder}")
            return

        train_dataset = MyDataset(data_folder=data_folder) # 实例化自己的数据集类

        # 打印出通道数不是由的图片的索引，使用showSignalImg找到删除
        for i in range(train_dataset.__len__()):
            sample_data, sample_label = train_dataset.__getitem__(i)
            # print(f"每个tensor的尺寸{sample_data.size()[0]}")
            if sample_data.size()[0] != 3:
                print(f"index:{i}的通道数为{sample_data.size()[0]}")

        train_loader = DataLoader(train_dataset, batch_size=16, shuffle=False)
        print('总共有 %s 个批次用于训练' % (len(train_loader)))
        # for i,(data, label) in enumerate(train_loader):
        #     print(data.size(), label.size())
        for i in tqdm(range(len(train_loader))):
            sleep(0.1)
        print(f"数据集加载完成")

    except Exception as e:
        print(f"错误发生: {e}")

if __name__=='__main__':
    testAllImg()
    # showSignalImg(294)

