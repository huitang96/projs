import torch
import torch.nn.functional as F

# torch.set_default_tensor_type('torch.FloatTensor')
torch.set_default_tensor_type('torch.cuda.FloatTensor')

# 构造模型
class Net(torch.nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = torch.nn.Conv2d(1, 32, (5, 5), padding=(2, 2), bias=True)
        self.conv2 = torch.nn.Conv2d(32, 64, (5, 5), padding=(2, 2), bias=True)
        self.conv3 = torch.nn.Conv2d(64, 128, (5, 5), padding=(2, 2), bias=True)
        self.fc1 = torch.nn.Linear(128 * 3 * 3, 128, bias=True)
        self.fc2 = torch.nn.Linear(128, 10, bias=True)

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv3(x)), (2, 2))
        x = x.reshape(-1, 128 * 3 * 3)
        x = F.relu(self.fc1(x))
        y = self.fc2(x)
        z = F.softmax(y, dim=1)
        z = torch.argmax(z, dim=1)
        # return y, z
        return y

nHeight = 28
nWidth = 28
onnxFile = "./model.onnx"
# trtFile = "./model.engine"

device = 'cuda' if torch.cuda.is_available() else 'cpu'

model = Net()
model.load_state_dict(torch.load('save.pt'))

# torch.onnx.export(model, torch.randn(1, 1, nHeight, nWidth, device=device), onnxFile, input_names=["x"], output_names=["y", "z"], do_constant_folding=True, verbose=True, keep_initializers_as_inputs=True, opset_version=12, dynamic_axes={"x": {0: "nBatchSize"}, "z": {0: "nBatchSize"}})
# torch.onnx.export(model, torch.randn(1, 1, nHeight, nWidth, device=device), onnxFile, input_names=["x"], output_names=["y"], do_constant_folding=True, verbose=True, keep_initializers_as_inputs=True, opset_version=12, dynamic_axes={"x": {0: "nBatchSize"}, "z": {0: "nBatchSize"}})

torch.onnx.export(model, torch.randn(1, 1, nHeight, nWidth, device=device), './model.onnx', input_names=['x'], output_names=['y'], verbose='True')


print("Succeeded converting model into ONNX!")


"""

python -m onnxsim model.onnx init_sim.onnx
"""