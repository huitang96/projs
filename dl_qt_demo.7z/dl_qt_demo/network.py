import math
import torch.nn as nn
class Flatten(nn.Module):
    def __init__(self):
        super(Flatten, self).__init__()
    def forward(self,x):
        return x.view(x.size(0), -1)

class  MyNet_v1(nn.Module):
    def __init__(self, num_class):
        super(MyNet_v1, self).__init__()
        C = num_class
        self.conv_layer1 = nn.Sequential(
            nn.Conv2d(in_channels=3, out_channels=64, kernel_size=7, stride=1, padding=7//2),
            nn.BatchNorm2d(64),
            nn.LeakyReLU(0.1),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        self.conv_layer2 = nn.Sequential(
            nn.Conv2d(in_channels=64, out_channels=192, kernel_size=3, stride=1, padding=3 // 2),
            nn.BatchNorm2d(192),
            nn.LeakyReLU(0.1),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv_layer3 = nn.Sequential(
            nn.Conv2d(in_channels=192, out_channels=384, kernel_size=3, stride=1, padding=3 // 2),
            nn.BatchNorm2d(384),
            nn.LeakyReLU(0.1),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.flatten = Flatten() # 对flatten类进行实例化
        self.conn_layer1 = nn.Sequential(
            nn.Linear(in_features=37 * 37 * 384,
                      out_features=512),
            nn.Dropout(0.5),
            nn.LeakyReLU(0.1))
        self.conn_layer2 = nn.Sequential(
            nn.Linear(in_features=512,
                      out_features=C))
        self._initialize_weights()

    def forward(self, input):
        x = self.conv_layer1(input)
        x = self.conv_layer2(x)
        x = self.conv_layer3(x)
        x = self.flatten(x)
        x = self.conn_layer1(x)
        output = self.conn_layer2(x)
        return output

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()


import cv2
import torchvision.transforms as transforms
from PIL import Image
if __name__=='__main__':
    Net = MyNet_v1(2)
    # print(Net)
    # 加载图像
    image_path = '/home/thui/projects/datasets/dog2cat/dogcat/dog/1.jpg'  # 替换为你的图像路径
    image = cv2.imread(image_path)
    image = cv2.resize(image, (300, 300))
    img_pil = Image.fromarray(image)  # 将 NumPy 数组转换为 PIL 图像

    # 转换为tensor送入网络
    transform = transforms.ToTensor()
    image_tensor = transform(img_pil)
    image_tensor = image_tensor.unsqueeze(0)

    # 将图像传递给神经网络进行计算
    output = Net(image_tensor) # 没有权重，只进行一次FP计算张量
    # 打印或处理输出结果
    print(output)
