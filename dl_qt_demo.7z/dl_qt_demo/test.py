import torchvision
import torch
from PIL import Image
import torch.nn.functional as F

# 构造模型
class Net(torch.nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = torch.nn.Conv2d(1, 32, (5, 5), padding=(2, 2), bias=True)
        self.conv2 = torch.nn.Conv2d(32, 64, (5, 5), padding=(2, 2), bias=True)
        self.conv3 = torch.nn.Conv2d(64, 128, (5, 5), padding=(2, 2), bias=True)
        self.fc1 = torch.nn.Linear(128 * 3 * 3, 128, bias=True)
        self.fc2 = torch.nn.Linear(128, 10, bias=True)

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv3(x)), (2, 2))
        x = x.reshape(-1, 128 * 3 * 3)
        x = F.relu(self.fc1(x))
        y = self.fc2(x)
        z = F.softmax(y, dim=1)
        z = torch.argmax(z, dim=1)
        # return y, z
        return y


# 读取图像
img = Image.open("/home/thui/projects/pythonProject/1.png")
# 数据预处理

# 缩放
transform = torchvision.transforms.Compose([torchvision.transforms.Resize((28, 28)),
                                            torchvision.transforms.ToTensor()])
image = transform(img)
# print(image.shape)

# 根据保存方式加载
# model = Net()
# model.load_state_dict(torch.load('save.pt'))
# model = torch.load('save.pt', map_location='cpu')

model = Net()
model.load_state_dict(torch.load('save.pt'))
# model.eval()
# model = torch.load("save.pt", map_location=torch.device('cpu'))

# 注意维度转换，单张图片
# image1 = torch.reshape(image, (1, 1, 28, 28))
image1 = image.unsqueeze(0)
# print(image1.shape)

# 测试开关
model.eval()
# 节约性能
with torch.no_grad():
    output = model(image1)
# print(output)
# print(output[1].item())
print(f'预测结果:{output.argmax(1).numpy()[0]}')
# 定义类别对应字典
dist = {0: "0", 1: "1", 2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9"}
# 转numpy格式,列表内取第一个
a = dist[output.argmax(1).numpy()[0]]
img.show()
# print(a)
