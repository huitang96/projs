import torchvision.datasets

from data import MyDataset
from torch.utils.data import DataLoader

import os
from datetime import datetime as dt
from glob import glob
# import calibrator
import cv2
import numpy as np
# import tensorrt as trt
import torch
import torch.nn.functional as F
# from cuda import cudart
from torch.autograd import Variable

# 相关参数
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# 构造模型
class Net(torch.nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = torch.nn.Conv2d(1, 32, (5, 5), padding=(2, 2), bias=True)
        self.conv2 = torch.nn.Conv2d(32, 64, (5, 5), padding=(2, 2), bias=True)
        self.conv3 = torch.nn.Conv2d(64, 128, (5, 5), padding=(2, 2), bias=True)
        self.fc1 = torch.nn.Linear(128 * 3 * 3, 128, bias=True)
        self.fc2 = torch.nn.Linear(128, 10, bias=True)

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv3(x)), (2, 2))
        x = x.reshape(-1, 128 * 3 * 3)
        x = F.relu(self.fc1(x))
        y = self.fc2(x)
        z = F.softmax(y, dim=1)
        z = torch.argmax(z, dim=1)
        # return y, z
        return y

import torchvision.transforms as transforms

model = Net().to(device)
# Define the loss function with Classification Cross-Entropy loss and an optimizer with Adam optimizer
loss_fn = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)

trainDataset = torchvision.datasets.MNIST(root='/home/thui/projects/datasets/onnx', train=True,
                                          transform=transforms.ToTensor(), download = True)
valDataset = torchvision.datasets.MNIST(root='/home/thui/projects/datasets/onnx', train=False,
                                          transform=transforms.ToTensor(), download = True)

trainLoader = DataLoader(dataset=trainDataset, batch_size=64, shuffle=True)
valLoader = DataLoader(dataset=valDataset, batch_size=64, shuffle=True)

# Training Function
def train(num_epochs):
    best_accuracy = 0.0

    print("Begin training...")
    for epoch in range(1, num_epochs + 1):
        running_train_loss = 0.0
        running_accuracy = 0.0
        running_vall_loss = 0.0
        total = 0

        # Training Loop
        for data in trainLoader:
            # for data in enumerate(train_loader, 0):
            inputs, outputs = data  # get the input and real species as outputs; data is a list of [inputs, outputs]
            inputs = inputs.to(device)
            outputs = outputs.to(device)
            optimizer.zero_grad()  # zero the parameter gradients
            predicted_outputs = model(inputs)  # predict output from the model
            train_loss = loss_fn(predicted_outputs, outputs)  # calculate loss for the predicted output
            train_loss.backward()  # backpropagate the loss
            optimizer.step()  # adjust parameters based on the calculated gradients
            running_train_loss += train_loss.item()  # track the loss value

        # Calculate training loss value
        train_loss_value = running_train_loss / len(trainLoader)

        # Validation Loop
        with torch.no_grad():
            model.eval()
            for images, labels in valLoader:
                images = images.to(device)
                labels = labels.to(device)
                predicted_outputs = model(images)
                val_loss = loss_fn(predicted_outputs, labels)

                # The label with the highest value will be our prediction
                _, predicted = torch.max(predicted_outputs, 1)
                running_vall_loss += val_loss.item()
                total += labels.size(0)
                running_accuracy += (predicted == labels).sum().item()

                # Calculate validation loss value
        val_loss_value = running_vall_loss / len(valLoader)

        # Calculate accuracy as the number of correct predictions in the validation batch divided by the total number of predictions done.
        accuracy = (100 * running_accuracy / total)

        # Save the model if the accuracy is the best
        if accuracy > best_accuracy:
            # saveModel()
            torch.save(model.state_dict(), 'save.pt')
            best_accuracy = accuracy

            # Print the statistics of the epoch
        print('Completed training batch', epoch, 'Training Loss is: %.4f' % train_loss_value,
              'Validation Loss is: %.4f' % val_loss_value, 'Accuracy is %d %%' % (accuracy))


if __name__ == '__main__':
    train(20)