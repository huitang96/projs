import cv2

img = cv2.imread("/home/thui/projects/pythonProject/4.jpg", cv2.IMREAD_GRAYSCALE)
cv2.imwrite("/home/thui/projects/pythonProject/4_gray.jpg", img)
print("转换完成")
